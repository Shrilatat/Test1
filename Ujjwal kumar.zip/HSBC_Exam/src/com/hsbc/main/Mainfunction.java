/*
 * Author : ujjwal Kumar Singh
 * purpose: This is the main method
 * */

package com.hsbc.main;

import java.util.Scanner;

import com.hsbc.logic.ApparelData;
import com.hsbc.logic.ElectronicsData;
import com.hsbc.logic.FoodItemData;

public class Mainfunction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FoodItemData objFoodItemData = new FoodItemData();
		ElectronicsData objElectronicData = new ElectronicsData();
		ApparelData objApparelData = new ApparelData();


		boolean loop=true;
		while (loop) {
			Scanner sc = new Scanner(System.in);
			int choice;
			System.out.println("1. Enter Data in Food Item");
			System.out.println("2. Retrieve Data in Food Item");
			System.out.println("3. Enter Data in Apparel Item");
			System.out.println("4. Retrieve Data in Apparel Item");
			System.out.println("5. Enter Data in Electronics Item");
			System.out.println("6. Retireve Data From Electronics Item");
			System.out.println("0. To exit from program : ");
			choice = sc.nextInt();
			sc.close();
			switch (choice) {
			case 0 : loop=false;break;
			case 1 : objFoodItemData.addItems();break;
			case 2 : objFoodItemData.retirev();break;
			case 3 : objElectronicData.addItems(); break;
			case 4 : objElectronicData.retirev();break;
			case 5 : objApparelData.addItems();break;
			case 6 : objApparelData.retirev();break;
			default: System.out.println("wrong choice");
			}

		}

	}

}
