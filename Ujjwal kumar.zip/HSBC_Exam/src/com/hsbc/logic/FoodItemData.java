/*
 * Author : Ujjwal Kumar Singh
 * Purpose: This is where Food item data is store
 * */
package com.hsbc.logic;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.hsbc.obj.FoodItem;

public class FoodItemData implements DataAccess{
	List<FoodItem> obj = new ArrayList<>();
	@Override
	public void addItems() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Item code for food item :");
		int itemcode = sc.nextInt();
		
		System.out.println("Enter Item name :");
		String name = sc.next();
		
		System.out.println("Enter Item unit price :");	
		int price = sc.nextInt();
		
		System.out.println("Enter Date of manufacture :");
		String DateOfManufacture = sc.next();
		
		System.out.println("Enter expiry date :");
		String expiryDate = sc.next();
		
		System.out.println("Enter vegetrain (yes/no):");
		String veg = sc.next();
		
		System.out.println("Enter Item Quantity :");
		int quantity = sc.nextInt();
		
		obj.add(new FoodItem(itemcode , name , price ,DateOfManufacture, expiryDate , veg , quantity));		
		sc.close();
		
	}

	@Override
	public void retirev() {
		for(FoodItem f : obj) {
			System.out.println(f);
		}
	}
	
}
