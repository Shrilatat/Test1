/*
 * Author : Ujjwal Kumar Singh
 * Purpose: 
 * */
package com.hsbc.logic;

interface DataAccess {
	public void addItems();
	public void retirev();
}
