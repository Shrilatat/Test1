/*
 * Author : Ujjwal Kumar Singh
 * Purpose: This is where electronics data is store
 * */
package com.hsbc.logic;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.hsbc.obj.Electronics;

public class ElectronicsData implements DataAccess{
	List<Electronics> obj = new ArrayList<>();
	@Override
	public void addItems() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Item code for electronic item :");
		int itemcode = sc.nextInt();

		System.out.println("Enter Item name :");
		String name = sc.next();

		System.out.println("Enter Item unit price :");
		int price = sc.nextInt();

		System.out.println("Enter Warranty in months:");
		int warranty = sc.nextInt();

		System.out.println("Enter Item Quantity :");
		int quantity = sc.nextInt();
		
		obj.add(new Electronics(itemcode , name , price, warranty , quantity));
		sc.close();
		
	}

	@Override
	public void retirev() {
		// TODO Auto-generated method stub
		for(Electronics e : obj) {
			System.out.println(e);
		}
	}
	

}
