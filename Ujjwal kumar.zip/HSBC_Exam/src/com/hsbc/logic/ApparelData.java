/*
 * Author : Ujjwal Kumar Singh
 * Purpose: 
 * */
package com.hsbc.logic;
/*
 * Author : ujjwal kumar Singh
 * purpose: this is where Apparel data is store
 * */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.hsbc.obj.Apparel;

public class ApparelData implements DataAccess {
	List<Apparel> obj = new ArrayList<>();

	@Override
	public void addItems() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Item code for apparel item :");
		int itemcode = sc.nextInt();

		System.out.println("Enter Item name :");
		String name = sc.next();

		System.out.println("Enter Item unit price :");
		int price = sc.nextInt();

		System.out.println("Enter Apparel Item size :");
		String size = sc.next();

		System.out.println("Enter Material");
		String material = sc.next();

		System.out.println("Enter Item Quantity :");
		int quantity = sc.nextInt();

		obj.add(new Apparel(itemcode, name, price, size, material, quantity));
		sc.close();

	}

	@Override
	public void retirev() {
		for(Apparel a : obj) {
			System.out.println(a);
		}

	}
}
